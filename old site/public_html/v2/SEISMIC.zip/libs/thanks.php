<?php ?>
<!DOCTYPE html>
<html>
<head></head>
<body>
    <p>Thanks, we have your message and will reply soon.</p>
    <br>
    <p>Click <a href="../index.html">here</a> to return to the site.</p>
</body>
</html>